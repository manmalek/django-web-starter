def selected_theme(request):
    # return the value you want as a dictionnary. you may add multiple values in there.
    return {'SELECTED_THEME': 'main.html'}